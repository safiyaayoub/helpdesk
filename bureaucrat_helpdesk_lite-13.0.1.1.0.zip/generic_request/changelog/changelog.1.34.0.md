Added categories for request event types
