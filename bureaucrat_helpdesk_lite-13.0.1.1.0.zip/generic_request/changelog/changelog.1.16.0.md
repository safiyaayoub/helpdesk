Added `active` field to Request Stage
