- Public (unregistered) users can see website UI of service desk.
  All steps of request creation are visible.
  On the final stage of request submission, all control items are disabled until the user is registered.
  Additional link for registration is displayed on the screen.
