- Added ability to redirect user to *My Requests* page after
  user clicked on website action (route).
  Added field *Website Extra Action* to request route model.
- Show on 'My Requests' filter requests that have current
  user as author but not creator
- Fix toolbar for texteditor in dialog, when response on request is required:
    - show buttons to change colors
    - show single button for *upload file*
      (instead of dropdown with *insert image* and *upload file*)
    - remove button for *horizontal rule* and *remove format*
    - remove buttons for *subscript* and *superscript*
