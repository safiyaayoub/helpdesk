Changed `generic.mixin.name_with_code`: generate new code only if there is no code
